let students = [];

document.getElementById("studentForm").addEventListener("submit", async function(e) {
    e.preventDefault();

    const id = document.getElementById("studentId").value;
    const data = {
        name: document.getElementById("name").value.trim(),
        roll_number: document.getElementById("roll_number").value.trim(),
        email: document.getElementById("email").value.trim(),
        department: document.getElementById("department").value.trim(),
        year: document.getElementById("year").value
    };

    if (!data.name || !data.roll_number || !data.email || !data.department || !data.year) {
        showMessage("Please fill all fields.", true);
        return;
    }

    if (data.year < 1 || data.year > 4) {
        showMessage("Year must be between 1 and 4.", true);
        return;
    }

    const url = id ? `/api/students/${id}/` : "/api/students/";
    const method = id ? "PUT" : "POST";

    const response = await fetch(url, {
        method,
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(data)
    });
    const result = await response.json();

    if (response.ok) {
        showMessage(id ? "Student updated successfully." : "Student added successfully.");
        resetForm();
        loadStudents();
    } else {
        showMessage(result.error || "Operation failed.", true);
    }
});

async function loadStudents() {
    const response = await fetch("/api/students/");
    students = await response.json();

    const search = document.getElementById("search").value.toLowerCase();
    const filtered = students.filter(s =>
        s.name.toLowerCase().includes(search) ||
        s.roll_number.toLowerCase().includes(search) ||
        s.department.toLowerCase().includes(search)
    );

    document.getElementById("studentTable").innerHTML = filtered.map(s => `
        <tr>
            <td>${s.id}</td>
            <td>${s.name}</td>
            <td>${s.roll_number}</td>
            <td>${s.email}</td>
            <td>${s.department}</td>
            <td>${s.year}</td>
            <td>
                <button class="action" onclick="editStudent(${s.id})">Edit</button>
                <button class="action" onclick="deleteStudent(${s.id})">Delete</button>
            </td>
        </tr>
    `).join("");
}

async function editStudent(id) {
    const response = await fetch(`/api/students/${id}/`);
    const s = await response.json();

    document.getElementById("studentId").value = s.id;
    document.getElementById("name").value = s.name;
    document.getElementById("roll_number").value = s.roll_number;
    document.getElementById("email").value = s.email;
    document.getElementById("department").value = s.department;
    document.getElementById("year").value = s.year;
    document.getElementById("saveBtn").textContent = "Update Student";
    window.scrollTo({top: 0, behavior: "smooth"});
}

async function deleteStudent(id) {
    if (!confirm("Are you sure you want to delete this student?")) return;

    const response = await fetch(`/api/students/${id}/`, {method: "DELETE"});
    const result = await response.json();

    if (response.ok) {
        showMessage(result.message);
        loadStudents();
    } else {
        showMessage(result.error || "Delete failed.", true);
    }
}

function resetForm() {
    document.getElementById("studentForm").reset();
    document.getElementById("studentId").value = "";
    document.getElementById("saveBtn").textContent = "Add Student";
}

function showMessage(text, error=false) {
    const box = document.getElementById("message");
    box.textContent = text;
    box.style.color = error ? "crimson" : "green";
}

loadStudents();
