import json
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import Student

def home(request):
    return render(request, "index.html")

def student_to_dict(student):
    return {
        "id": student.id,
        "name": student.name,
        "roll_number": student.roll_number,
        "email": student.email,
        "department": student.department,
        "year": student.year,
    }

@csrf_exempt
def student_list_create(request):
    if request.method == "GET":
        students = Student.objects.all().order_by("id")
        return JsonResponse([student_to_dict(s) for s in students], safe=False)

    if request.method == "POST":
        try:
            data = json.loads(request.body)
            name = str(data.get("name", "")).strip()
            roll_number = str(data.get("roll_number", "")).strip()
            email = str(data.get("email", "")).strip()
            department = str(data.get("department", "")).strip()
            year = data.get("year")

            if not all([name, roll_number, email, department, year]):
                return JsonResponse({"error": "All fields are required."}, status=400)

            if not str(year).isdigit() or int(year) < 1 or int(year) > 4:
                return JsonResponse({"error": "Year must be between 1 and 4."}, status=400)

            if Student.objects.filter(roll_number=roll_number).exists():
                return JsonResponse({"error": "Roll number already exists."}, status=400)
            if Student.objects.filter(email=email).exists():
                return JsonResponse({"error": "Email already exists."}, status=400)

            student = Student.objects.create(
                name=name,
                roll_number=roll_number,
                email=email,
                department=department,
                year=int(year),
            )
            return JsonResponse(student_to_dict(student), status=201)
        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON data."}, status=400)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    return JsonResponse({"error": "Method not allowed."}, status=405)

@csrf_exempt
def student_detail(request, student_id):
    try:
        student = Student.objects.get(id=student_id)
    except Student.DoesNotExist:
        return JsonResponse({"error": "Student not found."}, status=404)

    if request.method == "GET":
        return JsonResponse(student_to_dict(student))

    if request.method in ["PUT", "PATCH"]:
        try:
            data = json.loads(request.body)
            name = str(data.get("name", "")).strip()
            roll_number = str(data.get("roll_number", "")).strip()
            email = str(data.get("email", "")).strip()
            department = str(data.get("department", "")).strip()
            year = data.get("year")

            if not all([name, roll_number, email, department, year]):
                return JsonResponse({"error": "All fields are required."}, status=400)

            if not str(year).isdigit() or int(year) < 1 or int(year) > 4:
                return JsonResponse({"error": "Year must be between 1 and 4."}, status=400)

            if Student.objects.filter(roll_number=roll_number).exclude(id=student_id).exists():
                return JsonResponse({"error": "Roll number already exists."}, status=400)
            if Student.objects.filter(email=email).exclude(id=student_id).exists():
                return JsonResponse({"error": "Email already exists."}, status=400)

            student.name = name
            student.roll_number = roll_number
            student.email = email
            student.department = department
            student.year = int(year)
            student.save()
            return JsonResponse(student_to_dict(student))
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)

    if request.method == "DELETE":
        student.delete()
        return JsonResponse({"message": "Student deleted successfully."})

    return JsonResponse({"error": "Method not allowed."}, status=405)
