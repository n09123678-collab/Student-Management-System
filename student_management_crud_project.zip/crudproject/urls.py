from django.urls import path
from students import views

urlpatterns = [
    path("", views.home, name="home"),
    path("api/students/", views.student_list_create, name="student_list_create"),
    path("api/students/<int:student_id>/", views.student_detail, name="student_detail"),
]
